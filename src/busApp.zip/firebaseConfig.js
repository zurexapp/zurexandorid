export const firebaseConfig = {
    apiKey: "AIzaSyCQ0pFmslNymOWFWNbbt8Y2uwhxs2TuRAE",
    authDomain: "aczurex-d4b61.firebaseapp.com",
    databaseURL: "https://aczurex-d4b61-default-rtdb.firebaseio.com",
    projectId: "aczurex-d4b61",
    storageBucket: "aczurex-d4b61.appspot.com",
    messagingSenderId: "31992218561",
    appId: "1:31992218561:web:4a78b4751dfe5cf1562540",
    measurementId: "G-99S7QS47T7"
  };