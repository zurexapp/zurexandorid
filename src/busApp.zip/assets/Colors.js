const textcolor = '#5E5E5E';
const maincolor = '#15488A';
const greencolor = '#4bae4f';
const redcolor = '#9F2734';
const c0color = '#c0c0c0';
const lightgreycolor = '#FBFBFB';
const borderColor = '#BFD0E5';
const graphSecondColor = '#FAB6BD';
const goldenColor = '#E88B0E';
const ratingColor = '#FAC917';
const WhiteColor = '#FFFFFF';
const graphyTxtColor = '#0e0e0e';
export {
  textcolor,
  maincolor,
  greencolor,
  redcolor,
  c0color,
  lightgreycolor,
  borderColor,
  graphSecondColor,
  goldenColor,
  ratingColor,
  WhiteColor,
  graphyTxtColor,
};
